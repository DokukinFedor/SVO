from PIL import Image

a = open('input.txt', 'r')
list = a.readlines()


# im1.paste(im2, (150, 150))
# im1.save("finish.png")


if '0' '1' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("0-1.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '1' '2' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("0-13.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '2' '3' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("2-3.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '3' '4' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("3-4.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '3' '5' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("3-5.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '5' '6' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("5-6.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '5' '8' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("5-8.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '7' '8' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("7-8.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '8' '9' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("8-9.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '9' '10' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("9-10.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '9' '12' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("9-12.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '11' '12' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("11-12.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '12' '13' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("11.png")
    im3 = Image.open("12.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")
if '0' '13' in list:
    im1 = Image.open("bg.png")
    im2 = Image.open("0-13.png")
    im1.paste(im2, (150, 150))
    im1.save("finish2.png")

f = open('data.txt', 'w')

points = sorted(list(map(int, input().split())))


def min_way(start, end):
    graph = [[1, 13], [0, 2], [1, 3], [2, 4, 5], [3], [3, 6, 8], [5], [8], [5, 7, 9], [8, 10, 11], [9], [12],
             [9, 11, 13], [0, 12]]
    matrix = [[0, 6845, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10000], [6845, 0, 46830, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 46830, 0, 6845, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 6845, 0, 5800, 14700, 0, 0, 0, 0, 0, 0, 0, 0],
              [0, 0, 0, 5800, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 14700, 0, 0, 5800, 0, 13690, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 5800, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 7200, 0, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 13690, 0, 7200, 0, 14700, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0, 14700, 0, 5800, 30600, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 5800, 0, 0, 0, 0],
              [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5800, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 30600, 0, 5800, 0, 7200],
              [10000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7200, 0]]

    def all_paths(graph, start, end):
        queue = [(start, [start])]
        while queue:
            (v, path) = queue.pop(0)
            for next in list(set(graph[v]) - set(path)):
                if next == end:
                    yield path + [next]
                else:
                    queue.append((next, path + [next]))

    paths = list(all_paths(graph, start, end))
    lengths = []
    for elem in paths:
        sum_ = 0
        for i in range(len(elem) - 1):
            sum_ += matrix[elem[i]][elem[i + 1]]
        lengths.append(sum_)
    return paths[lengths.index(min(lengths))]


route = []
for i in range(len(points) - 1):
    route.append(min_way(points[i], points[i + 1]))
for elem in route:
    for i in range(len(elem) - 1):
        print(elem[i], elem[i + 1], file=f)
f.close()